package com.example.convertirunidades;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.convertirunidades.R;

public class MainActivity extends AppCompatActivity {

    private EditText etValue;
    private Spinner spinnerUnits;
    private Button btnConvert;
    private TextView tvResult;

    private static final double METRO_A_KILOMETRO = 0.001;
    private static final double METRO_A_CENTIMETRO = 100;
    private static final double METRO_A_MILIMETRO = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializamos los elementos de la interfaz
        etValue = findViewById(R.id.et_value);
        spinnerUnits = findViewById(R.id.spinner_units);
        btnConvert = findViewById(R.id.btn_convert);
        tvResult = findViewById(R.id.tv_result);

        // Adaptador para el Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_to_unit, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUnits.setAdapter(adapter);

        // Acción del botón Convertir
        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertUnits();
            }
        });
    }

    private void convertUnits() {
        String inputValue = etValue.getText().toString();

        if (inputValue.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese un valor", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(inputValue);
        String selectedUnit = spinnerUnits.getSelectedItem().toString();
        double result = 0;
        String resultUnit = "";

        switch (selectedUnit) {
            case "Kilómetro":
                result = value * METRO_A_KILOMETRO;
                resultUnit = "Km";
                break;
            case "Centímetro":
                result = value * METRO_A_CENTIMETRO;
                resultUnit = "cm";
                break;
            case "Milímetro":
                result = value * METRO_A_MILIMETRO;
                resultUnit = "mm";
                break;
            case "Metro":
                result = value;
                resultUnit = "m";
                break;
        }

        tvResult.setText(String.format("Resultado: %.2f %s", result, resultUnit));
    }
}